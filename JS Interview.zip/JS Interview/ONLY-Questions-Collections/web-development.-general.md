### Random Web-Development questions I faced or collected from discussion with others ( Slack Group / Facebook Group )

1> How to gracefully shut-down an web-app