## After pushing a commit how to chanage the comments in that commit - Applicable for the most recent commit - 26Jun2018

https://gist.github.com/nepsilon/156387acf9e1e72d48fa35c4fabef0b4#already-pushed--most-recent-commit

## git commit --amend

It will open in-Termianl- text editor, edit the commit message and save the commit. By following the command at the bottom of the Terminal. Ctrl + O for writing out. Then Enter > It will show the file within .git directory, where the amed is being saved. > Enter again > Ctrl + X to exit. Then run below command.

## git push origin master --force