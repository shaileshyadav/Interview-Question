 When building a single page app, we need to make sure that our navigation is not getting re-rendered when we go from one page to another. That is how single page app experience in the first place.

